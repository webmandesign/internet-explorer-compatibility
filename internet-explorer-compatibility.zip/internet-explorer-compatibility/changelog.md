# Internet Explorer Compatibility Changelog

## 1.0.0, 20210104

- Initial release.
